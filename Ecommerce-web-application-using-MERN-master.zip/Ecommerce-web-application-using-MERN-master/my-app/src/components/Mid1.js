import React from 'react'
import "./Mid1.css";
const Mid1 = () => {
  return (
      <section class="collection-container">
    <a href="#" class="collection">
        <img src="https://images-na.ssl-images-amazon.com/images/G/31/img19/Fashion/WA19/DressStore_Sobe/updates/kurta._SS680_QL85_.jpg" alt="">
        </img><p class="collection-title">women  apparels</p>
    </a>
    <a href="#" class="collection">
        <img src="https://m.media-amazon.com/images/I/61O67XkTQHL._UX466_.jpg" alt="">
        </img> <p class="collection-title">men apparels</p>
    </a>
    <a href="#" class="collection">
        <img src="https://m.media-amazon.com/images/I/71uwxk2BlCL._SL1100_.jpg" alt="">
        </img> <p class="collection-title">kids apparels</p>
    </a>
    <a href="#" class="collection">
        <img src="https://images-na.ssl-images-amazon.com/images/G/31/img19/Jew/Dec/EOSS/SBCMen/434x530-SBC-Accessories-6._SY530_QL85_.jpg" alt="">
        </img><p class="collection-title">accessories</p>
    </a>
</section>
  )
}

export default Mid1

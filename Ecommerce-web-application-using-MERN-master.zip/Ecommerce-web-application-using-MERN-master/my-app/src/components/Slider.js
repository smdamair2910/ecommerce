import React from "react";
import "./Slider.css";

const Slider = () => {
  return (
    <div>
      <header class="head-section">
      <div class="content">
 <p class="sub-heading">Best clothing and accessories collection of all time</p>
     </div>
     </header>
    </div>
  )
}

export default Slider

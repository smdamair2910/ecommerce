import React from 'react'
import "./Announcement.css";
const Announcement = () => {
  return (
       <div class="container">
         <marquee scrollment="100">
         Grand Deal! Shop upto Rs. 2000 get FREE SHIPPING</marquee>
         </div>
    
  );
};

export default Announcement;
